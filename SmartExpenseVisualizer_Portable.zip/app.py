import streamlit as st # type: ignore
from components.sidebar import sidebar
from components.calendar_view import calendar_view
from components.charts import charts_view
from components.smart_insights import insights_view

from features.add_expense import add_expense
from features.export_data import export_data
from features.budget_alerts import check_budget_alerts
from features.monthly_comparison import show_monthly_comparison
from features.recurring_detector import detect_recurring_expenses
from features.voice_input import voice_to_text_input
from chatbot.bot import chatbot_tab
from utils.helpers import load_data

st.set_page_config(page_title="Smart Expense Visualizer", layout="wide")
sidebar()

data = load_data()

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📅 Calendar View", 
    "📊 Charts", 
    "🧠 Smart Insights", 
    "🛠 Add/View/Edit", 
    "📤 Export",
    "🤖 Chatbot"
])

with tab1:
    calendar_view(data)

with tab2:
    charts_view(data)

with tab3:
    insights_view(data)
    detect_recurring_expenses(data)
    check_budget_alerts(data)

with tab4:
    voice_to_text_input()
    add_expense()

with tab5:
    export_data(data)
    show_monthly_comparison(data)

with tab6:
    chatbot_tab()
