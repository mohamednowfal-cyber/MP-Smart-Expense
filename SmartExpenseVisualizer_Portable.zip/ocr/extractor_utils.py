import re

def extract_expenses_from_text(text):
    # Very basic regex-based extraction logic
    lines = text.split('\n')
    expenses = []

    for line in lines:
        match = re.search(r'(\d+)[\s-]*(\w+)', line)
        if match:
            amount = float(match.group(1))
            category = match.group(2).capitalize()
            expenses.append({"Amount": amount, "Category": category, "Note": line.strip()})
    
    return expenses
