import os
import pytesseract
from PIL import Image
from typing import Union


def _configure_tesseract_cmd() -> None:
    """Optionally set the Tesseract executable path via env var TESSERACT_CMD.

    On Windows, users often need to set this to something like:
    C:\\Program Files\\Tesseract-OCR\\tesseract.exe
    """
    tcmd = os.getenv("TESSERACT_CMD")
    if tcmd:
        pytesseract.pytesseract.tesseract_cmd = tcmd


def _image_to_text(img: Image.Image) -> str:
    _configure_tesseract_cmd()
    return pytesseract.image_to_string(img)


def scan_bill(image_path: Union[str, os.PathLike]) -> str:
    img = Image.open(image_path)
    return _image_to_text(img)


def scan_bill_file(file_obj) -> str:
    """Scan from a file-like object (e.g., Streamlit uploader)."""
    img = Image.open(file_obj)
    return _image_to_text(img)
