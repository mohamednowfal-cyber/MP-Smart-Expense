import matplotlib.pyplot as plt
import pandas as pd

def draw_category_chart():
    # Read data from CSV file
    df = pd.read_csv("expenses_summary.csv")  # Update with your actual filename

    # Ensure columns are named correctly
    # Example: Amount, Category, Date
    df["Amount"] = pd.to_numeric(df["Amount"], errors="coerce")

    if df.empty:
        return None

    category_sum = df.groupby("Category")["Amount"].sum()

    fig, ax = plt.subplots()
    category_sum.plot(kind='bar', ax=ax, color='skyblue')
    ax.set_title("Expenses by Category")
    ax.set_ylabel("Amount (₹)")
    ax.set_xlabel("Category")
    return fig