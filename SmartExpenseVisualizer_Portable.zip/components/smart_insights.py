import streamlit as st

def insights_view(data):
    st.subheader("🧠 Smart Insights")
    
    # Check if data is empty
    if data.empty:
        st.info("📊 No expense data available yet. Add some expenses to see insights!")
        return
    
    # Check if required columns exist
    if 'Date' not in data.columns or 'Amount' not in data.columns or 'Category' not in data.columns:
        st.warning("⚠️ Data format issue. Please ensure your data has 'Date', 'Amount', and 'Category' columns.")
        return
    
    try:
        # Get top spending day
        daily_totals = data.groupby('Date')['Amount'].sum()
        if not daily_totals.empty:
            top_day = daily_totals.idxmax()
            top_day_amount = daily_totals.max()
            st.markdown(f"- 💸 **Most expensive day:** `{top_day}` (₹{top_day_amount:,.2f})")
        else:
            st.markdown("- 💸 **Most expensive day:** No data available")
        
        # Get top spending category
        category_totals = data.groupby('Category')['Amount'].sum()
        if not category_totals.empty:
            top_category = category_totals.idxmax()
            top_category_amount = category_totals.max()
            st.markdown(f"- 🏷 **Top spending category:** `{top_category}` (₹{top_category_amount:,.2f})")
        else:
            st.markdown("- 🏷 **Top spending category:** No data available")
            
        # Additional insights
        total_expenses = data['Amount'].sum()
        avg_expense = data['Amount'].mean()
        st.markdown(f"- 💰 **Total expenses:** ₹{total_expenses:,.2f}")
        st.markdown(f"- 📈 **Average expense:** ₹{avg_expense:,.2f}")
        
    except Exception as e:
        st.error(f"Error generating insights: {str(e)}")
        st.info("Please check your data format and try again.")
