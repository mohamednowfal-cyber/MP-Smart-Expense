import streamlit as st
import pandas as pd

def calendar_view(data):
    st.subheader("📅 Calendar View")
    
    # Check if data is empty
    if data.empty:
        st.info("📊 No expense data available yet. Add some expenses to see the calendar view!")
        return
    
    # Check if required columns exist
    if 'Date' not in data.columns or 'Category' not in data.columns or 'Amount' not in data.columns:
        st.warning("⚠️ Data format issue. Please ensure your data has 'Date', 'Category', and 'Amount' columns.")
        return
    
    try:
        # Convert Date column to datetime
        data['Date'] = pd.to_datetime(data['Date'], errors='coerce')
        
        # Remove rows with invalid dates
        data = data.dropna(subset=['Date'])
        
        if data.empty:
            st.warning("⚠️ No valid date data found. Please check your date format.")
            return
        
        # Display summary statistics
        total_expenses = data['Amount'].sum()
        total_days = len(data['Date'].dt.date.unique())
        avg_daily = total_expenses / total_days if total_days > 0 else 0
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Expenses", f"₹{total_expenses:,.2f}")
        with col2:
            st.metric("Days with Expenses", total_days)
        with col3:
            st.metric("Average Daily", f"₹{avg_daily:,.2f}")
        
        st.markdown("---")
        
        # Group by date and display
        for date in sorted(data['Date'].unique()):
            day_data = data[data['Date'] == date]
            day_total = day_data['Amount'].sum()
            
            with st.expander(f"📅 {date.strftime('%A, %d %B %Y')} - ₹{day_total:,.2f}"):
                # Display expenses for this day
                display_columns = ['Category', 'Amount']
                if 'Note' in day_data.columns:
                    display_columns.append('Note')
                
                # Format the table
                display_data = day_data[display_columns].copy()
                display_data['Amount'] = display_data['Amount'].apply(lambda x: f"₹{x:,.2f}")
                
                st.table(display_data)
                
                # Show category breakdown
                if len(day_data) > 1:
                    st.markdown("**Category Breakdown:**")
                    category_breakdown = day_data.groupby('Category')['Amount'].sum().sort_values(ascending=False)
                    for category, amount in category_breakdown.items():
                        st.markdown(f"- {category}: ₹{amount:,.2f}")
        
    except Exception as e:
        st.error(f"Error displaying calendar view: {str(e)}")
        st.info("Please check your data format and try again.")
