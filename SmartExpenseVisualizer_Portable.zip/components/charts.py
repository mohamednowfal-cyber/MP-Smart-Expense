import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

def charts_view(data):
    st.subheader("📊 Charts")
    
    # Check if data is empty
    if data.empty:
        st.info("📊 No expense data available yet. Add some expenses to see charts!")
        return
    
    # Check if required columns exist
    if 'Category' not in data.columns or 'Amount' not in data.columns:
        st.warning("⚠️ Data format issue. Please ensure your data has 'Category' and 'Amount' columns.")
        return
    
    try:
        # Category spending chart
        category_data = data.groupby('Category')["Amount"].sum()
        if not category_data.empty:
            st.write("**Spending by Category**")
            st.bar_chart(category_data)
        else:
            st.info("No category data available for charting.")
        
        # Check if Date column exists for daily chart
        if 'Date' in data.columns:
            daily = data.groupby('Date')["Amount"].sum()
            if not daily.empty:
                st.write("**Daily Spending Trend**")
                st.line_chart(daily)
            else:
                st.info("No daily data available for charting.")
        else:
            st.info("Date column not found. Daily spending chart not available.")
            
    except Exception as e:
        st.error(f"Error generating charts: {str(e)}")
        st.info("Please check your data format and try again.")
