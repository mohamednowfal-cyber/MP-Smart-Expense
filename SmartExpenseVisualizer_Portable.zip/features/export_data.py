import streamlit as st
import pandas as pd

def export_data(data):
    st.subheader("📤 Export Data")

    csv = data.to_csv(index=False).encode('utf-8')
    st.download_button(
        "Download as CSV",
        csv,
        "expenses.csv",
        "text/csv"
    )

    st.markdown("📎 PDF and Excel export options can be added using `xlsxwriter` and `fpdf` if needed.")

    # Settings UI removed per revert request